'use strict'
var $ = require('jquery')
var ethJSABI = require('ethereumjs-abi')
var ethJSUtil = require('ethereumjs-util')
var BN = ethJSUtil.BN
var helper = require('./txHelper')
var TreeView = require('ethereum-remix').ui.TreeView
var executionContext = require('../../execution-context')

module.exports = {
  /**
    * build the transaction data
    *
    * @param {Object} contract    - abi definition of the current contract.
    * @param {Object} contracts    - map of all compiled contracts.
    * @param {Bool} isConstructor    - isConstructor.
    * @param {Object} funAbi    - abi definition of the function to call. null if building data for the ctor.
    * @param {Object} params    - input paramater of the function to call
    * @param {Object} udapp    - udapp
    * @param {Function} callback    - callback
    */
  buildData: function (contract, contracts, isConstructor, funAbi, params, udapp, callback) {
    var funArgs = ''
    try {
      funArgs = $.parseJSON('[' + params + ']')
    } catch (e) {
      callback('Error encoding arguments: ' + e)
      return
    }
    var data = ''
    var dataHex = ''
    if (!isConstructor || funArgs.length > 0) {
      try {
        data = helper.encodeParams(funAbi, funArgs)
        dataHex = data.toString('hex')
      } catch (e) {
        callback('Error encoding arguments: ' + e)
        return
      }
    }
    if (data.slice(0, 9) === 'undefined') {
      dataHex = data.slice(9)
    }
    if (data.slice(0, 2) === '0x') {
      dataHex = data.slice(2)
    }
    if (isConstructor) {
      var bytecodeToDeploy = contract.bytecode
      if (bytecodeToDeploy.indexOf('_') >= 0) {
        this.linkBytecode(contract, contracts, udapp, (err, bytecode) => {
          if (err) {
            callback('Error deploying required libraries: ' + err)
          } else {
            bytecodeToDeploy = bytecode + dataHex
            return callback(null, bytecodeToDeploy)
          }
        })
        return
      } else {
        dataHex = bytecodeToDeploy + dataHex
      }
    } else {
      dataHex = Buffer.concat([helper.encodeFunctionId(funAbi), data]).toString('hex')
    }
    callback(null, dataHex)
  },

  atAddress: function () {},

  linkBytecode: function (contract, contracts, udapp, callback) {
    var bytecode = contract.bytecode
    if (bytecode.indexOf('_') < 0) {
      return callback(null, bytecode)
    }
    var m = bytecode.match(/__([^_]{1,36})__/)
    if (!m) {
      return callback('Invalid bytecode format.')
    }
    var libraryName = m[1]
    var libraryabi = helper.getContractByName(libraryName, contracts)
    if (!libraryabi) {
      return callback('Library ' + libraryName + ' not found.')
    }
    this.deployLibrary(libraryabi, udapp, (err, address) => {
      if (err) {
        return callback(err)
      }
      var libLabel = '__' + libraryName + Array(39 - libraryName.length).join('_')
      var hexAddress = address.toString('hex')
      if (hexAddress.slice(0, 2) === '0x') {
        hexAddress = hexAddress.slice(2)
      }
      hexAddress = Array(40 - hexAddress.length + 1).join('0') + hexAddress
      while (bytecode.indexOf(libLabel) >= 0) {
        bytecode = bytecode.replace(libLabel, hexAddress)
      }
      contract.bytecode = bytecode
      this.linkBytecode(contract, contracts, udapp, callback)
    })
  },

  deployLibrary: function (libraryName, library, udapp, callback) {
    var address = library.address
    if (address) {
      return callback(null, address)
    }
    var bytecode = library.bytecode
    if (bytecode.indexOf('_') >= 0) {
      this.linkBytecode(libraryName, (err, bytecode) => {
        if (err) callback(err)
        else this.deployLibrary(libraryName, callback)
      })
    } else {
      udapp.runTx({ data: bytecode, useCall: false }, (err, txResult) => {
        if (err) {
          return callback(err)
        }
        var address = executionContext.isVM() ? txResult.result.createdAddress : txResult.result.contractAddress
        library.address = address
        callback(err, address)
      })
    }
  },

  decodeResponse: function (response, fnabi, callback) {
    // Only decode if there supposed to be fields
    var treeView = new TreeView({
      extractData: (item, parent, key) => {
        var ret = {}
        if (BN.isBN(item)) {
          ret.self = item.toString(10)
          ret.children = []
        } else {
          ret = treeView.extractDataDefault(item, parent, key)
        }
        return ret
      }
    })
    if (fnabi.outputs && fnabi.outputs.length > 0) {
      try {
        var i

        var outputTypes = []
        for (i = 0; i < fnabi.outputs.length; i++) {
          outputTypes.push(fnabi.outputs[i].type)
        }

        // decode data
        var decodedObj = ethJSABI.rawDecode(outputTypes, response)

        // format decoded data
        var json = {}
        for (i = 0; i < outputTypes.length; i++) {
          var name = fnabi.outputs[i].name
          if (name.length > 0) {
            json[outputTypes[i] + ' ' + name] = decodedObj[i]
          } else {
            json[outputTypes[i]] = decodedObj[i]
          }
        }

        return callback(null, treeView.render(json))
      } catch (e) {
        return callback('Failed to decode output: ' + e)
      }
    }
  }
}
