'use strict'

require('./compiler-test')
require('./gist-handler-test')
require('./query-params-test')
require('./util-test')
require('./staticanalysis/staticAnalysisCommon-test')
require('./staticanalysis/staticAnalysisIntegration-test')
